py -m venv venv
venv/Scripts/python.exe venv/bin/pip3.exe install -r src/requirements-win.txt
venv/Scripts/python.exe src/main.pyw
